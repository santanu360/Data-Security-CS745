#!/bin/bash

mitm/mitmweb -p 3128 --web-host 0.0.0.0 &
